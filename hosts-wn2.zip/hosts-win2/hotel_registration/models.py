from django.db import models
from django.contrib.auth import get_user_model
from phonenumber_field.modelfields import PhoneNumberField
from django import forms

# Create your models here.
# User = get_user_model()

user_type_role = (
    ('administrator', 'Administrator'),
    ('management', 'Management'),
    ('supervisor', 'Supervisor'),
    ('user', 'users'),
)

constitution = (
    ('proprietor', 'Proprietor'),
    ('partner', 'Partner'),
    ('llc', 'LLC'),
    ('company', 'Company'),
)


class Hotel(models.Model):
    hotel_name = models.CharField(max_length=50, null=False)
    address = models.CharField(max_length=100, null=False)
    country = models.CharField(max_length=50, blank=False, null=False)
    country_code = models.CharField(max_length=50, blank=False, null=False)
    state = models.CharField(max_length=50, blank=False, null=False)
    city = models.CharField(max_length=50, blank=False, null=False)
    gst_no = models.CharField(max_length=50, blank=False, null=False)
    email = models.EmailField(null=False, blank=False)
    cin_no = models.CharField(max_length=30, blank=False, null=False)
    phone = models.CharField(max_length=12, null=False, blank=False, unique=True)
    group_name = models.CharField(max_length=50, blank=False, null=False)
    company = models.CharField(max_length=50, blank=False, null=False)
    pan_no = models.CharField(max_length=10, blank=False, null=False)
    constitution = models.CharField(max_length=10, choices=constitution, default='Select your constitution')
    postal_code = models.IntegerField(blank=False)
    image = models.ImageField(upload_to='upload/')

    # constitution = models.CharField(label='Select your constitution', widget=forms.Select(choices=constitution))
    def __str__(self):
        return self.hotel_name


class Users(models.Model):
    hotel_name = models.ForeignKey(Hotel, on_delete=models.CASCADE, blank=False)
    user_name = models.CharField(max_length=50, null=False, blank=False)
    user_type_role = models.CharField(max_length=15, choices=user_type_role, default='Select your Role', blank=False)
    email = models.EmailField(null=False, blank=False)
    phone = models.CharField(max_length=12, null=False, blank=False, unique=True)

    def __str__(self):
        return self.user_name


class Reservation(models.Model):
    hotel_name = models.ForeignKey(Hotel, on_delete=models.CASCADE, blank=False)
    user_name = models.CharField(max_length=50, null=False, blank=False)
    user_type_role = models.CharField(max_length=15, choices=user_type_role, default='Select your Role', blank=False)
    email = models.EmailField(null=False, blank=False)
    phone = models.CharField(max_length=12, null=False, blank=False, unique=True)

    def __str__(self):
        return self.user_name
