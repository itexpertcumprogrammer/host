from rest_framework import serializers
from .models import Hotel


class HotelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hotel
        fields = '__all__'

        '''fields = ('hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email', 'country_code', 'cin_no',
                  'phone', 'group_name', 'company', 'pan_no', 'constitution', 'postal_code', 'image')'''
