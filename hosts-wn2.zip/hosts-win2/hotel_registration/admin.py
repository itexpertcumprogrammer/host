from django.contrib import admin
from .models import Hotel, Users


# Register your models here.
@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email', 'country_code', 'cin_no', 'phone',
        'group_name', 'company', 'pan_no', 'constitution', 'postal_code', 'image')


# Register your models here.
@admin.register(Users)
class UsersAdmin(admin.ModelAdmin):
    list_display = ('user_name', 'email', 'phone', 'user_type_role', 'hotel_name')
