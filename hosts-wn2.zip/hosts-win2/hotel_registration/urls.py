# -*- encoding: utf-8 -*-
from django.conf import settings
from django.conf.urls.static import static

from django.urls import path, include
from .views import add_show, user_show, reservation, Test_View, HotelCreateApi, HotelApi, HotelUpdateApi, HotelDeleteApi
from hotel_registration import views

from rest_framework.authtoken.views import obtain_auth_token

# from core.views import PostView, PostCreateView, PostListCreateView

urlpatterns = [
    path('addandshow/', add_show, name="addandshow"),
    path('delete/<int:id>/', views.delete_data, name="deletedata"),
    path('update/<int:id>/', views.update_data, name="updatedata"),
    path('export_csv_hotel', views.export_csv_hotel, name="export_csv_hotel"),
    path('export_hotel_xls', views.export_hotel_xls, name="export_hotel_xls"),
    path('export_pdf_hotel', views.export_pdf_hotel, name="export_pdf_hotel"),

    path('useraddshow/', user_show, name='useraddshow'),
    path('deleteuser/<int:id>/', views.delete_user, name='deleteuser'),
    path('updateuser/<int:id>/', views.update_user, name='updateuser'),
    path('export_csv/', views.export_csv, name='export_csv'),
    path('excel/', views.export_users_xls, name='export_excel'),
    path('export_pdf/', views.export_pdf, name="export_pdf"),

    path('reservation/', views.reservation, name="reservation"),

    path('api-auth/', include('rest_framework.urls')),
    path('rest-auth/', include('rest_auth.urls')),
    # path('api_view', HotelView.as_view(), name='test'),
    # path('create/', HotelCreateView.as_view(), name='create'),
    # path('list-create/', HotelListCreateView.as_view(), name='list-create'),
    # path('api/token/', obtain_auth_token, name='obtain-token'),
    path('Test_View', Test_View, name='Test_View'),
    # path('deleteapi/<int:pk>/', views.HotelView.as_view(), name=deleteapi),
    path('hotel_data',HotelApi.as_view(), name='hotel_data'),
    path('create', HotelCreateApi.as_view()),
    path('updatedata/<int:pk>', HotelUpdateApi.as_view(), name='updatadata'),
    path('delete/<int:pk>', HotelDeleteApi.as_view()),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
