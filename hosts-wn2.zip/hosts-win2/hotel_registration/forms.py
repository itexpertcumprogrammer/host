from django import forms
from django.forms import ModelForm
from .models import Hotel, Users


class HotelRegistration(forms.ModelForm):
    class Meta:
        model = Hotel

        fields = ['hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email', 'country_code', 'cin_no',
                  'phone', 'group_name', 'company', 'pan_no', 'constitution', 'postal_code', 'image']
        widgets = {
            'hotel_name': forms.TextInput(
                attrs={'placeholder': 'Hotel Name', 'class': 'form-control form-control-alternative'}),
            'address': forms.TextInput(
                attrs={'placeholder': 'Address', 'class': 'form-control form-control-alternative'}),
            'country': forms.TextInput(
                attrs={'placeholder': 'country', 'class': 'form-control form-control-alternative'}),
            'state': forms.TextInput(attrs={'placeholder': 'state', 'class': 'form-control form-control-alternative'}),
            'city': forms.TextInput(attrs={'placeholder': 'city', 'class': 'form-control form-control-alternative'}),
            'gst_no': forms.TextInput(
                attrs={'placeholder': 'gst_no', 'class': 'form-control form-control-alternative'}),
            'email': forms.TextInput(attrs={'placeholder': 'E-Mail', 'class': 'form-control form-control-alternative'}),
            'cin_no': forms.TextInput(
                attrs={'placeholder': 'cin_no', 'class': 'form-control form-control-alternative'}),
            'phone': forms.TextInput(attrs={'placeholder': 'phone', 'class': 'form-control form-control-alternative'}),
            'country_code': forms.TextInput(
                attrs={'placeholder': 'country_code', 'class': 'form-control form-control-alternative'}),
            'group_name': forms.TextInput(
                attrs={'placeholder': 'group_name', 'class': 'form-control form-control-alternative'}),
            'company': forms.TextInput(
                attrs={'placeholder': 'company', 'class': 'form-control form-control-alternative'}),
            'pan_no': forms.TextInput(
                attrs={'placeholder': 'pan_no', 'class': 'form-control form-control-alternative'}),
            'constitution': forms.Select(attrs={'placeholder': 'Select your constitution',
                                                'class': 'category form-control form-control-alternative'}),
            'postal_code': forms.TextInput(
                attrs={'placeholder': 'postal_code', 'class': 'form-control form-control-alternative'}),
        }


class UserRegistration(forms.ModelForm):
    class Meta:
        model = Users
        fields = ['hotel_name', 'user_type_role', 'user_name', 'email', 'phone']
        widgets = {
            'hotel_name': forms.Select(
                attrs={'placeholder': 'Select Hotel Name', 'class': 'form-control form-control-alternative'}),
            'user_name': forms.TextInput(
                attrs={'placeholder': 'User Name', 'class': 'form-control form-control-alternative'}),
            'user_type_role': forms.Select(
                attrs={'placeholder': 'Select your Role', 'class': 'form-control form-control-alternative'}),
            'email': forms.TextInput(attrs={'placeholder': 'email', 'class': 'form-control form-control-alternative'}),
            'phone': forms.TextInput(attrs={'placeholder': 'phone', 'class': 'form-control form-control-alternative'}),
        }


# def clean(self):
#     super(Users, self).clean()
#
#     # getting username and password from cleaned_data
#     hotel_name = self.cleaned_data.get('hotel_name')
#     user_name = self.cleaned_data.get('user_name')
#     phone = self.cleaned_data.get('phone')
#     email = self.cleaned_data.get('email')
#
#     # validating the username and password
#     if hotel_name == ' ':
#         self._errors['user_name'] = self.error_class(['Choose Your Hotel Name'])
#
#     if len(user_name) < 4:
#         self._errors['user_name'] = self.error_class(['A minimum of 3 characters is required'])
#
#     if len(email) > 6:
#         self._errors['email'] = self.error_class(['Enter Correct Email Address'])
#         if re.match('\b[\w\.-]+@[\w\.-]+\.\w{2,4}\b', email) is not None:
#             return 1
#
#     if len(phone) < 10:
#         self._errors['phone'] = self.error_class(['Mobile Number length should not be less than 10 characters'])
#
#     return self.cleaned_data
#

# hotel reservation code
class HotelReservation(forms.ModelForm):
    class Meta:
        model = Users
        fields = ['hotel_name', 'user_type_role', 'user_name', 'email', 'phone']
        widgets = {
            'hotel_name': forms.Select(
                attrs={'placeholder': 'Select Hotel Name', 'class': 'form-control form-control-alternative'}),
            'user_name': forms.TextInput(
                attrs={'placeholder': 'User Name', 'class': 'form-control form-control-alternative'}),
            'user_type_role': forms.Select(
                attrs={'placeholder': 'Select your Role', 'class': 'form-control form-control-alternative'}),
            'email': forms.TextInput(attrs={'placeholder': 'email', 'class': 'form-control form-control-alternative'}),
            'phone': forms.TextInput(attrs={'placeholder': 'phone', 'class': 'form-control form-control-alternative'}),
        }