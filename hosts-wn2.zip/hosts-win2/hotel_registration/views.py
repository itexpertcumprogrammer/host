import csv
# from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from rest_framework.decorators import parser_classes
from rest_framework.parsers import MultiPartParser, FormParser
import xlwt
from django.contrib.auth import authenticate
from django.shortcuts import render, HttpResponseRedirect, HttpResponse
from django.http import JsonResponse
from hotel_registration.models import Hotel, Users, Reservation
from .forms import HotelRegistration, UserRegistration, HotelReservation
from django.template.loader import get_template
from xhtml2pdf import pisa
from io import StringIO, BytesIO

# third party imports
from rest_framework import generics
from rest_framework.response import Response
# from .serializer import HotelSerializer
# from .models import Hotel
# from rest_framework.generics import ListAPIView, UpdateAPIView, RetrieveAPIView, DestroyAPIView

from .serializers import HotelSerializer


# from .models import Post


# Create your views here.


# This Function Will Add New Item and Show All Items
def add_show(request):
    msg = None
    success = False

    if request.method == 'POST':
        form = HotelRegistration(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            hn = form.cleaned_data['hotel_name']
            ad = form.cleaned_data['address']
            country = form.cleaned_data['country']
            c_code = form.cleaned_data['country_code']
            state = form.cleaned_data['state']
            city = form.cleaned_data['city']
            gst = form.cleaned_data['gst_no']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            cin = form.cleaned_data['cin_no']
            gn = form.cleaned_data['group_name']
            comp = form.cleaned_data['company']
            pan = form.cleaned_data['pan_no']
            const = form.cleaned_data['constitution']
            postal_code = form.cleaned_data['postal_code']
            image = form.cleaned_data['image']
            form = authenticate(hotel_name=hn, address=ad, country=country, country_code=c_code, state=state, city=city,
                                gst_no=gst, email=email, phone=phone, cin_no=cin, group_name=gn, company=comp,
                                pan_no=pan, constitution=const, postal_code=postal_code, image=image)

            msg = 'Hotel has been Successfully Registered...!'
            success = True

        else:

            msg = 'Form is not valid... Please check carefully'
            # form = HotelRegistration()

    else:

        form = HotelRegistration()
    stud = Hotel.objects.all()
    return render(request, "hotel/addandshow.html", {'form': form, "msg": msg, "success": success, 'stu': stud})


# This Function will Update/Edit
def update_data(request, id):
    msg = None
    success = False
    if request.method == 'POST':
        pi = Hotel.objects.get(pk=id)
        form = HotelRegistration(request.POST, request.FILES, instance=pi)
        if form.is_valid():
            form.save()
            hn = form.cleaned_data['hotel_name']
            ad = form.cleaned_data['address']
            country = form.cleaned_data['country']
            c_code = form.cleaned_data['country_code']
            state = form.cleaned_data['state']
            city = form.cleaned_data['city']
            gst = form.cleaned_data['gst_no']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            cin = form.cleaned_data['cin_no']
            gn = form.cleaned_data['group_name']
            comp = form.cleaned_data['company']
            pan = form.cleaned_data['pan_no']
            const = form.cleaned_data['constitution']
            postal_code = form.cleaned_data['postal_code']
            image = form.cleaned_data['image']
            form = authenticate(hotel_name=hn, address=ad, country=country, country_code=c_code, state=state, city=city,
                                gst_no=gst, email=email, phone=phone, cin_no=cin, group_name=gn, company=comp,
                                pan_no=pan, constitution=const, postal_code=postal_code, image=image)

            msg = 'Hotel has been Successfully Updated...!'
            success = True
    else:
        pi = Hotel.objects.get(pk=id)
        form = HotelRegistration(instance=pi)
    return render(request, 'hotel/update_hotel.html', {'form': form, "msg": msg, "success": success})


# This Function will Delete
def delete_data(request, id):
    if request.method == 'POST':
        pi = Hotel.objects.get(pk=id)
        pi.delete()
        # messages.success(request, 'Hotel Deleted Successfully.')
        return HttpResponseRedirect('/addandshow/')


# This Function Will Add New user and Show All users
def user_show(request):
    msg = None
    success = False

    if request.method == 'POST':
        form = UserRegistration(request.POST)
        if form.is_valid():
            form.save()
            un = form.cleaned_data['user_name']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            u_type = form.cleaned_data['user_type_role']
            hn = form.cleaned_data['hotel_name']
            form = authenticate(user_name=un, email=email, phone=phone, user_type_role=u_type, hotel_name=hn)

            msg = 'User has been Successfully Registered...!'
            success = True

        else:
            msg = 'Form is not valid... Please check carefully'
            # fmu = UserRegistration()
    else:
        form = UserRegistration()
    stud1 = Users.objects.all()
    return render(request, "hotel/useraddshow.html", {'form': form, "msg": msg, "success": success, 'stud': stud1})


# This Function will Update/Edit
def update_user(request, id):
    msg = None
    success = False
    if request.method == 'POST':
        pi = Users.objects.get(pk=id)
        form = UserRegistration(request.POST, instance=pi)
        if form.is_valid():
            form.save()
            un = form.cleaned_data['user_name']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            u_type = form.cleaned_data['user_type_role']
            hn = form.cleaned_data['hotel_name']
            form = authenticate(user_name=un, email=email, phone=phone, user_type_role=u_type, hotel_name=hn)
            msg = 'User has been Successfully Updated...!'
            success = True
            # return HttpResponseRedirect('/useraddshow/')

        else:
            msg = 'Form is not valid... Please check carefully'
    else:
        pi = Users.objects.get(pk=id)
        form = UserRegistration(instance=pi)
    return render(request, "hotel/update_user.html", {'form': form, "msg": msg, "success": success})


# This Function will Delete
def delete_user(request, id):
    if request.method == 'POST':
        pi = Users.objects.get(pk=id)
        pi.delete()
        # messages.success(request, 'Hotel Deleted Successfully.')
        return HttpResponseRedirect('/useraddshow/')


# THIS CODE IS FOR EXPORT IN CSV (FOR USERS)
def export_csv(request):
    response = HttpResponse(content_type='text/csv')
    # response['Content-Disposition'] = 'attachment; filename="RegisterUsers.csv"'

    writer = csv.writer(response)
    writer.writerow(['Hotel Name', 'User Name', 'User Type', 'E-Mail Address', 'Mobile Number'])

    # hotel = Users.objects.all().value_list()

    for ht in Users.objects.all().values_list('hotel_name', 'user_name', 'user_type_role', 'email', 'phone'):
        writer.writerow(ht)

    response['Content-Disposition'] = 'attachment; filename="users.csv"'

    return response


# THIS CODE IS FOR EXPORT IN CSV (FOR HOTEL)
def export_csv_hotel(request):
    response = HttpResponse(content_type='text/csv')
    # response['Content-Disposition'] = 'attachment; filename="RegisterUsers.csv"'

    writer = csv.writer(response)
    writer.writerow(['Hotel Name', 'Address', 'Country', 'State', 'City', 'GST Number', 'E-Mail Address',
                     'Country Code', 'CIN Number', 'Mobil Number', 'Group Name', 'Company Name', 'PAN Number',
                     'Constitutions', 'Postal Code', 'Image'])

    # hotel = Users.objects.all().value_list()

    for ht in Hotel.objects.all().values_list('hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email',
                                              'country_code', 'cin_no',
                                              'phone', 'group_name', 'company', 'pan_no', 'constitution', 'postal_code',
                                              'image'):
        writer.writerow(ht)

    response['Content-Disposition'] = 'attachment; filename="Hotels.csv"'

    return response


# this function is used for excel file generate (FOR USERS)
def export_users_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="users.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Users Data')  # this will make a sheet named Users Data

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Hotel Name', 'User Name', 'User Type', 'E-Mail Address', 'Mobile Number']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)  # at 0 row 0 column

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()

    rows = Users.objects.all().values_list('hotel_name', 'user_name', 'user_type_role', 'email', 'phone')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)

    return response


# this function is used for excel file generate (FOR HOTEL)
def export_hotel_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Hotels.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Hotels Data')  # this will make a sheet named Users Data

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Hotel Name', 'Address', 'Country', 'State', 'City', 'GST Number', 'E-Mail Address',
               'Country Code', 'CIN Number', 'Mobil Number', 'Group Name', 'Company Name', 'PAN Number',
               'Constitutions', 'Postal Code', 'Image']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)  # at 0 row 0 column

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()

    rows = Hotel.objects.all().values_list('hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email',
                                           'country_code', 'cin_no',
                                           'phone', 'group_name', 'company', 'pan_no', 'constitution', 'postal_code',
                                           'image')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)

    return response


# this function is used for PDF (FOR USERS)
def export_pdf(request):
    all_users = Users.objects.all()
    data = {'users': all_users}
    template = get_template("hotel/pdf.html")
    data_p = template.render(data)
    response = BytesIO()

    pdfPage = pisa.pisaDocument(BytesIO(data_p.encode("UTF-8")), response)
    if not pdfPage.err:
        return HttpResponse(response.getvalue(), content_type="application/pdf")
    else:
        return HttpResponse("Error Generating PDF")


# this function is used for PDF (FOR HOTEL)
def export_pdf_hotel(request):
    all_hotels = Hotel.objects.all()
    data = {'hotels': all_hotels}
    template = get_template("hotel/hotel_pdf.html")
    data_p = template.render(data)
    response = BytesIO()

    pdfPage = pisa.pisaDocument(BytesIO(data_p.encode("UTF-8")), response)
    if not pdfPage.err:
        return HttpResponse(response.getvalue(), content_type="application/pdf")
    else:
        return HttpResponse("Error Generating PDF")


# hotel reservation code here
def reservation(request):
    msg = None
    success = False

    if request.method == 'POST':
        form = UserRegistration(request.POST)
        if form.is_valid():
            form.save()
            un = form.cleaned_data['user_name']
            email = form.cleaned_data['email']
            phone = form.cleaned_data['phone']
            u_type = form.cleaned_data['user_type_role']
            hn = form.cleaned_data['hotel_name']
            form = authenticate(user_name=un, email=email, phone=phone, user_type_role=u_type, hotel_name=hn)

            msg = 'User has been Successfully Registered...!'
            success = True

        else:
            msg = 'Form is not valid... Please check carefully'
            # fmu = UserRegistration()
    else:
        form = UserRegistration()
    stud1 = Users.objects.all()
    return render(request, "hotel/hotel_reservation.html",
                  {'form': form, "msg": msg, "success": success, 'stud': stud1})


class HotelCreateApi(generics.CreateAPIView):
    queryset = Hotel.objects.all()
    for multi in Hotel.objects.all().values_list('hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email',
                                                 'country_code', 'cin_no',
                                                 'phone', 'group_name', 'company', 'pan_no', 'constitution',
                                                 'postal_code', 'image'):
        serializer_class = HotelSerializer


class HotelApi(generics.ListAPIView, generics.CreateAPIView):
    queryset = Hotel.objects.all()
    serializer_class = HotelSerializer

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs).delete()


class HotelUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = Hotel.objects.all()
    serializer_class = HotelSerializer

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs).delete()


class HotelDeleteApi(generics.DestroyAPIView):
    queryset = Hotel.objects.all()
    serializer_class = HotelSerializer


def Test_View(request):
    # permission_classes = (IsAuthenticated,)
    qs = Hotel.objects.all()
    post = qs.first()
    # serializer = PostSerializer(qs, many=True)
    serializer = HotelSerializer(post)
    return JsonResponse(serializer.data)
