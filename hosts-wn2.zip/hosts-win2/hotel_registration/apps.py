from django.apps import AppConfig


class HotelRegistrationConfig(AppConfig):
    name = 'hotel_registration'
