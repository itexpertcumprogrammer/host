# -*- encoding: utf-8 -*-
from django.conf.urls import url
from django.contrib import admin
from django.urls import path, include  # add this
from hotel_registration import views  # add this

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", include("authentication.urls")),  # add this
    path("", include("app.urls")),  # add this
    # path("", include("hotel_register.urls"))
    path("", include("hotel_registration.urls")) , # add this  # add this
    path("", include("hotel_room.urls"))  # add this  # add this
]
