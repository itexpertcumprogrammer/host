{% extends 'hotel/base.html' %}
{% block content %}
{% include "includes/sidenav.html" %}

  <div class="main-content">

    {% include "includes/navigation.html" %}

    {% include "includes/top_header_nav.html" %}

<div class="container-fluid mt--7">

    <div class="row">
      <div class="col">
        <div class="card shadow">
          <div class="card-header bg-transparent">
            <h3 class="mb-0">User Registraton</h3>
            <!--<h3 class="mb-0 text-right">Add New Hotel</h3>-->
          </div>
          <div class="card-body">
            <div class="row icon-examples">
                <!--<h1 class="h1">
                    <span>R</span>egister
                    <span>H</span>otel
                </h1><h4>Add New Hotel</h4>-->
                
                <div class="main-content-agile">
                    <div class="sub-main-w3">
                        <form action="" method="POST" autocomplete="off">
                            {% csrf_token %}{{form.as_p}}
                            <!--<div class="form-style-agile">
                                    <label>Hotel Name</label>
                                    {{form.hotel_name}}
                                </div>-->
                                <div class="form-style-agile" style="padding-bottom:2%;">
                                  <label>Hotel Name</label>
                                  <select class="category old-select" required="">
                                      <option value="" selected disabled="true">Select Your Hotel</option>
                                      <?php
                                            $db = mysqli_connect("localhost","root","","hotel_dashboard");  // Using database connection file here
                                            $records = mysqli_query($db, "SELECT hotel_registration_users.id, hotel_registration_users.email, hotel_registration_users.user_name, hotel_registration_users.phone, hotel_registration_users.user_type_role, hotel_registration_hotel.id FROM hotel_registration_users INNER JOIN hotel_registration_hotel ON hotel_registration_users.hotel_name_id=hotel_registration_hotel.id");  // Use select query here 
                                            echo $records;
                                            while($data = mysqli_fetch_asso($records))
                                            {
                                                echo "<option value='". $data['hotel_name_id'] ."'>" .$data['hotel_name'] ."</option>";  // displaying data in option menu
                                            }	
                                        ?>  
                                  </select>
                              </div>
                                <div class="w3layouts-grids">
                                    <div class="form-style-agile form-grids-w3l">
                                        <label>User Name</label>
                                        {{form.user_name}}
                                    </div>
                                    <div class="form-style-agile form-grids-w3l">
                                        <label>E-Mail Address</label>
                                        {{form.email}}
                                    </div>
                                </div>
                                <div class="w3layouts-grids">
                                    <div class="form-style-agile form-grids-w3l">
                                        <label>User Type</label>
                                        {{form.user_type_role}}
                                    </div>
                                    <div class="form-style-agile form-grids-w3l">
                                        <label>Mobile Number</label>
                                        {{form.phone}}
                                    </div>
                                </div>
                                <!--<div class="form-style-agile" style="padding-bottom:2%;">
                                    <label>Constitution</label>
                                    <select class="category old-select" required="">
                                        <option value="">Choose Your Constitution</option>
                                        <option value="proprietor">Proprietor</option>
                                        <option value="partner">Partner</option>
                                        <option value="llc">LLC</option>
                                        <option value="company">Company</option>
                                    </select>
                                </div>-->
                                <div class="align-self-center mx-auto"> 
                                    <button type="submit" class="button">Submit</button> 
                                </div> 
                                <!--<button type="submit" class="button" value="">Submit</button>-->
                                <!--<div class="container-login100-form-btn">
                                    <div class="wrap-login100-form-btn">
                                    <div class="login100-form-bgbtn"></div>
                                    <button type="submit" class="login100-form-btn">Login </button>
                                    </div>
                                    </div>--> 
                        </form>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  

<!------------------------------------- rocrd in table form (dark table)-->

<div class="row mt-5">
    <div class="col">
      <div class="card bg-default shadow">
        <div class="card-header bg-transparent border-0">
          <h3 class="text-white mb-0">Card tables</h3>
        </div>
        <div class="table-responsive">
        {% if stud %}            
          <table class="table align-items-center table-dark table-flush">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Hotel Name</th>
                    <th scope="col">User Name</th>
                    <th scope="col">E-Mail</th>
                    <th scope="col">Mobile Number</th>
                    <th scope="col">User Type</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
            {% for stu in stud %}
                <tr>
                    <th scope="row">
                      <div class="media align-items-center">
                        <div class="media-body">
                            {{stu.id}}
                        </div>
                      </div>
                    </th>
                    <td>
                      <span class="badge badge-dot mr-4">
                        {{stu.hotel_name}}
                      </span>
                    </td>
                    <td>
                        <span class="badge badge-dot mr-4">
                            {{stu.user_name}}
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-dot mr-4">
                            {{stu.email}}
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-dot mr-4">
                            {{stu.phone}}
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-dot mr-4">
                            {{stu.user_type_role}}
                        </span>
                    </td>
                    <td class="text-right">
                      <div class="dropdown">
                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-ellipsis-v"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                          <a class="dropdown-item" href="{% url 'updateuser' stu.id %}">Edit</a>
                          <form action="{% url 'deleteuser' stu.id %}" method="POST" class="d-inline">{% csrf_token %}
                              <button type="submit" class="dropdown-item" value="" style="cursor: pointer;">Delete</button>
                          </form>
                          <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                      </div>
                    </td>
                  </tr>
            {% endfor %}
            </tbody>
          </table>
            {% else %}
                <tr>    
                    <td>
                        <h4 class="text-center alert alert-warning">No Record</h4>
                    </td>
                </tr>
        {% endif %}
        </div>
      </div>
    </div>
  </div>
</div>
{% endblock content %}