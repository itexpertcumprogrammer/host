from django.contrib.auth import authenticate
from django.shortcuts import render
from django.shortcuts import render, HttpResponseRedirect, HttpResponse
from hotel_room.models import room_cat, room_rp, room_ms
from .forms import RoomRegistration, RoomRate, Room_Master
import xlwt
from django.template.loader import get_template
from xhtml2pdf import pisa
from io import StringIO, BytesIO
import csv

# Create your views here.


def add_room(request):
    msg = None
    success = False

    if request.method == 'POST':
        form = RoomRegistration(request.POST)
        if form.is_valid():
            form.save()
            rn = form.cleaned_data['room_cat_name']
            ad = form.cleaned_data['adult']
            ch = form.cleaned_data['child']
            rp = form.cleaned_data['rack_price']
            rno = form.cleaned_data['no_of_rooms']
            form = authenticate(room_cat_name=rn, adult=ad, child=ch, rack_price=rp, no_of_rooms=rno)

            msg = 'Room has been Successfully Registered...!'
            success = True

        else:

            msg = 'Form is not valid... Please check carefully'
            # form = HotelRegistration()

    else:
        form = RoomRegistration()
    room_cate = room_cat.objects.all()
    return render(request, "hotel_room/room_category.html",
                  {'form': form, "msg": msg, "success": success, 'stu': room_cate})


# This Function will Update/Edit
def update_room_cat(request, id):
    msg = None
    success = False
    if request.method == 'POST':
        pi = room_cat.objects.get(pk=id)
        form = RoomRegistration(request.POST, instance=pi)
        if form.is_valid():
            form.save()
            rn = form.cleaned_data['room_cat_name']
            ad = form.cleaned_data['adult']
            ch = form.cleaned_data['child']
            rp = form.cleaned_data['rack_price']
            rno = form.cleaned_data['no_of_rooms']
            form = authenticate(room_cat_name=rn, adult=ad, child=ch, rack_price=rp, no_of_rooms=rno)

            msg = 'Room has been Successfully Updated...!'
            success = True
    else:
        pi = room_cat.objects.get(pk=id)
        form = RoomRegistration(instance=pi)
    return render(request, "hotel_room/update_room.html", {'form': form, "msg": msg, "success": success})


def delete_room_cat(request, id):
    if request.method == 'POST':
        pi = room_cat.objects.get(pk=id)
        pi.delete()
        # messages.success(request, 'Hotel Deleted Successfully.')
        return HttpResponseRedirect('/room_category/')


def add_room_rate_plan(request):
    msg = None
    success = False

    if request.method == 'POST':
        form = RoomRate(request.POST)
        if form.is_valid():
            form.save()
            rn = form.cleaned_data['room_cat_name']
            hn = form.cleaned_data['hotel_name']
            rt = form.cleaned_data['rate_type']
            rate = form.cleaned_data['rate']
            vf = form.cleaned_data['valid_from']
            vt = form.cleaned_data['valid_to']
            dn = form.cleaned_data['display_name']
            eap = form.cleaned_data['extra_adult_price']
            ecp = form.cleaned_data['extra_child_price']
            form = authenticate(room_cat_name=rn, hotel_name=hn, rate_type=rt, rate=rate, valid_from=vf, valid_to=vt,
                                display_name=dn, extra_adult_price=eap, extra_child_price=ecp)

            msg = 'Room Rate Plan has been Successfully Registered...!'
            success = True

        else:

            msg = 'Form is not valid... Please check carefully'
            # form = HotelRegistration()

    else:
        form = RoomRate()
    room_rate_plan = room_rp.objects.all()
    return render(request, "hotel_room/room_rate_plan.html",
                  {'form': form, "msg": msg, "success": success, 'stud': room_rate_plan})


def update_room_rate_plan(request, id):
    msg = None
    success = False
    if request.method == 'POST':
        pi = room_rp.objects.get(pk=id)
        form = RoomRate(request.POST, instance=pi)
        if form.is_valid():
            form.save()
            rn = form.cleaned_data['room_cat_name']
            hn = form.cleaned_data['hotel_name']
            rt = form.cleaned_data['rate_type']
            rate = form.cleaned_data['rate']
            vf = form.cleaned_data['valid_from']
            vt = form.cleaned_data['valid_to']
            dn = form.cleaned_data['display_name']
            eap = form.cleaned_data['extra_adult_price']
            ecp = form.cleaned_data['extra_child_price']
            form = authenticate(room_cat_name=rn, hotel_name=hn, rate_type=rt, rate=rate, valid_from=vf, valid_to=vt,
                                display_name=dn, extra_adult_price=eap, extra_child_price=ecp)

            msg = 'Room Rate Plan has been Successfully Updated...!'
            success = True
    else:
        pi = room_rp.objects.get(pk=id)
        form = RoomRate(instance=pi)
    return render(request, "hotel_room/update_room_rate.html", {'form': form, "msg": msg, "success": success})


def delete_room_rate_plan(request, id):
    if request.method == 'POST':
        pi = room_rp.objects.get(pk=id)
        pi.delete()
        # messages.success(request, 'Hotel Deleted Successfully.')
        return HttpResponseRedirect('/room_rate_plan/')


def room_master(request):
    msg = None
    success = False

    if request.method == 'POST':
        form = Room_Master(request.POST)
        if form.is_valid():
            form.save()
            rn = form.cleaned_data['room_cat_name']
            hn = form.cleaned_data['hotel_name']
            rno = form.cleaned_data['room_no']
            floor = form.cleaned_data['floor']
            cp = form.cleaned_data['capacity']
            ab = form.cleaned_data['add_bed']
            form = authenticate(room_cat_name=rn, hotel_name=hn, room_no=rno, floor=floor, capacity=cp, add_bed=ab)
            msg = 'Room Master has been Successfully Registered...!'
            success = True

        else:

            msg = 'Form is not valid... Please check carefully'
            # form = HotelRegistration()

    else:
        form = Room_Master()
    room_mss = room_ms.objects.all()
    return render(request, "hotel_room/room_master.html",
                  {'form': form, "msg": msg, "success": success, 'studd': room_mss})


def update_room_master(request, id):
    msg = None
    success = False
    if request.method == 'POST':
        pi = room_ms.objects.get(pk=id)
        form = Room_Master(request.POST, instance=pi)
        if form.is_valid():
            form.save()
            rn = form.cleaned_data['room_cat_name']
            hn = form.cleaned_data['hotel_name']
            rno = form.cleaned_data['room_no']
            floor = form.cleaned_data['floor']
            cp = form.cleaned_data['capacity']
            ab = form.cleaned_data['add_bed']
            form = authenticate(room_cat_name=rn, hotel_name=hn, room_no=rno, floor=floor, capacity=cp, add_bed=ab)

            msg = 'Room Rate Plan has been Successfully Updated...!'
            success = True
    else:
        pi = room_ms.objects.get(pk=id)
        form = Room_Master(instance=pi)
    return render(request, "hotel_room/update_room_master.html", {'form': form, "msg": msg, "success": success})


def delete_room_master(request, id):
    if request.method == 'POST':
        pi = room_ms.objects.get(pk=id)
        pi.delete()
        # messages.success(request, 'Hotel Deleted Successfully.')
        return HttpResponseRedirect('/room_master/')


# THIS CODE IS FOR EXPORT IN CSV (FOR USERS)
def export_csv_room(request):
    response = HttpResponse(content_type='text/csv')
    # response['Content-Disposition'] = 'attachment; filename="RegisterUsers.csv"'

    writer = csv.writer(response)
    writer.writerow(['Room Category Name', 'Hotel Name', 'Adult', 'Child', 'Rack Price', 'Number Of Rooms'])

    # hotel = Users.objects.all().value_list()

    for ht in room_cat.objects.all().values_list('room_cat_name', 'hotel_name', 'adult', 'child', 'rack_price', 'no_of_rooms'):
        writer.writerow(ht)

    response['Content-Disposition'] = 'attachment; filename="Room Category.csv"'

    return response


# THIS CODE IS FOR EXPORT IN CSV (FOR HOTEL)
# def export_csv_hotel(request):
#     response = HttpResponse(content_type='text/csv')
#     # response['Content-Disposition'] = 'attachment; filename="RegisterUsers.csv"'
#
#     writer = csv.writer(response)
#     writer.writerow(['Hotel Name', 'Address', 'Country', 'State', 'City', 'GST Number', 'E-Mail Address',
#                      'Country Code', 'CIN Number', 'Mobil Number', 'Group Name', 'Company Name', 'PAN Number',
#                      'Constitutions', 'Postal Code', 'Image'])
#
#     # hotel = Users.objects.all().value_list()
#
#     for ht in Hotel.objects.all().values_list('hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email',
#                                               'country_code', 'cin_no',
#                                               'phone', 'group_name', 'company', 'pan_no', 'constitution', 'postal_code',
#                                               'image'):
#         writer.writerow(ht)
#
#     response['Content-Disposition'] = 'attachment; filename="Hotels.csv"'
#
#     return response


# this function is used for excel file generate (FOR USERS)
def export_users_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="users.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Users Data')  # this will make a sheet named Users Data

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Hotel Name', 'User Name', 'User Type', 'E-Mail Address', 'Mobile Number']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)  # at 0 row 0 column

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()

    rows = Users.objects.all().values_list('hotel_name', 'user_name', 'user_type_role', 'email', 'phone')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)

    return response


# this function is used for excel file generate (FOR HOTEL)
def export_hotel_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Hotels.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Hotels Data')  # this will make a sheet named Users Data

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Hotel Name', 'Address', 'Country', 'State', 'City', 'GST Number', 'E-Mail Address',
               'Country Code', 'CIN Number', 'Mobil Number', 'Group Name', 'Company Name', 'PAN Number',
               'Constitutions', 'Postal Code', 'Image']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)  # at 0 row 0 column

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()

    rows = Hotel.objects.all().values_list('hotel_name', 'address', 'country', 'state', 'city', 'gst_no', 'email',
                                           'country_code', 'cin_no',
                                           'phone', 'group_name', 'company', 'pan_no', 'constitution', 'postal_code',
                                           'image')
    for row in rows:
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)

    return response


# this function is used for PDF (FOR USERS)
def export_pdf(request):
    all_users = Users.objects.all()
    data = {'users': all_users}
    template = get_template("hotel/pdf.html")
    data_p = template.render(data)
    response = BytesIO()

    pdfPage = pisa.pisaDocument(BytesIO(data_p.encode("UTF-8")), response)
    if not pdfPage.err:
        return HttpResponse(response.getvalue(), content_type="application/pdf")
    else:
        return HttpResponse("Error Generating PDF")


# this function is used for PDF (FOR HOTEL)
def export_pdf_hotel(request):
    all_hotels = Hotel.objects.all()
    data = {'hotels': all_hotels}
    template = get_template("hotel/hotel_pdf.html")
    data_p = template.render(data)
    response = BytesIO()

    pdfPage = pisa.pisaDocument(BytesIO(data_p.encode("UTF-8")), response)
    if not pdfPage.err:
        return HttpResponse(response.getvalue(), content_type="application/pdf")
    else:
        return HttpResponse("Error Generating PDF")
