# -*- encoding: utf-8 -*-
from django.conf import settings
from django.conf.urls.static import static

from django.urls import path, include
from .views import add_room, add_room_rate_plan, room_master
from hotel_room import views

urlpatterns = [
    path('room_category/', add_room, name="room_category"),
    path('room_rate_plan/', add_room_rate_plan, name="room_rate_plan"),
    path('room_master/', room_master, name="room_master"),

    path('update_room/<int:id>/', views.update_room_cat, name='update_room_cat'),
    path('delete_room/<int:id>/', views.delete_room_cat, name='delete_room_cat'),
    path('export_csv_room', views.export_csv_room, name="export_csv_room"),

    path('update_room_rate/<int:id>/', views.update_room_rate_plan, name='update_room_rate'),
    path('delete_room_rate/<int:id>/', views.delete_room_rate_plan, name='delete_room_rate'),

    path('update_room_master/<int:id>/', views.update_room_master, name='update_room_master'),
    path('delete_room_master/<int:id>/', views.delete_room_master, name='delete_room_master'),
]
