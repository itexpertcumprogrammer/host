from django.db import models
from django.contrib.auth import get_user_model
from phonenumber_field.modelfields import PhoneNumberField
from django import forms

# Create your models here.
from hotel_registration.models import Hotel

ratetype = (
    ('CP', 'CP'),
    ('MAP', 'MAP'),
    ('AP', 'AP'),
    ('EP', 'EP'),
)

roomstatus = (
    ('Avilable', 'Avilable'),
    ('Not-Avilable', 'Not-Avilable'),
)


class room_cat(models.Model):
    room_cat_name = models.CharField(max_length=20, null=False)
    hotel_name = models.ForeignKey(Hotel, on_delete=models.CASCADE, blank=False)
    adult = models.IntegerField(blank=False)
    child = models.IntegerField(blank=False)
    rack_price = models.FloatField(blank=False)
    no_of_rooms = models.IntegerField(blank=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # constitution = models.CharField(label='Select your constitution', widget=forms.Select(choices=constitution))
    def __str__(self):
        return self.room_cat_name


class room_rp(models.Model):
    hotel_name = models.ForeignKey(Hotel, on_delete=models.CASCADE, blank=False)
    room_cat_name = models.ForeignKey(room_cat, on_delete=models.CASCADE, blank=False)
    rate_type = models.CharField(max_length=10, choices=ratetype, default='Select Rate Type')
    rate = models.CharField(max_length=20, null=False)
    valid_from = models.DateField(blank=True, null=True)
    valid_to = models.DateField(blank=True, null=True)
    display_name = models.CharField(max_length=30, null=False)
    extra_adult_price = models.FloatField(blank=False)
    extra_child_price = models.FloatField(blank=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # constitution = models.CharField(label='Select your constitution', widget=forms.Select(choices=constitution))
    def __str__(self):
        return self.room_cat_name


class room_ms(models.Model):
    hotel_name = models.ForeignKey(Hotel, on_delete=models.CASCADE, blank=False)
    room_cat_name = models.ForeignKey(room_cat, on_delete=models.CASCADE, blank=False)
    room_status = models.CharField(max_length=50, choices=roomstatus, default='Select Room Status')
    room_no = models.IntegerField(blank=False)
    floor = models.CharField(max_length=10, null=False)
    capacity = models.IntegerField(blank=False)
    add_bed = models.IntegerField(blank=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # constitution = models.CharField(label='Select your constitution', widget=forms.Select(choices=constitution))
    def __str__(self):
        return self.room_cat_name
# Create your models here.
