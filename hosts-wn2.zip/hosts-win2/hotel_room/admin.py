from django.contrib import admin
from .models import room_cat, room_rp, room_ms


# Register your models here.
@admin.register(room_cat)
class room_catAdmin(admin.ModelAdmin):
    list_display = (
        'room_cat_name', 'hotel_name', 'adult', 'child', 'rack_price', 'no_of_rooms')


@admin.register(room_rp)
class room_rpAdmin(admin.ModelAdmin):
    list_display = (
        'hotel_name', 'room_cat_name', 'rate_type', 'rate', 'valid_from', 'valid_to', 'display_name', 'extra_adult_price',
        'extra_child_price')


@admin.register(room_ms)
class room_msAdmin(admin.ModelAdmin):
    list_display = ('hotel_name', 'room_cat_name', 'room_no', 'room_status', 'floor', 'capacity', 'add_bed')
