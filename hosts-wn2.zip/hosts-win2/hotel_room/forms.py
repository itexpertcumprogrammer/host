from django import forms
from django.forms import ModelForm
from .models import room_cat, room_rp, room_ms
from hotel_registration.models import Hotel


class RoomRegistration(forms.ModelForm):
    class Meta:
        model = room_cat

        fields = ['room_cat_name', 'hotel_name', 'adult', 'child', 'rack_price', 'no_of_rooms']
        widgets = {
            'room_cat_name': forms.TextInput(
                attrs={'placeholder': 'room Name', 'class': 'form-control form-control-alternative'}),
            'hotel_name': forms.Select(attrs={'placeholder': 'Select Hotel Name',
                                              'class': 'category form-control form-control-alternative'}),
            'adult': forms.TextInput(attrs={'placeholder': 'adult', 'class': 'form-control form-control-alternative'}),
            'child': forms.TextInput(attrs={'placeholder': 'child', 'class': 'form-control form-control-alternative'}),
            'rack_price': forms.TextInput(
                attrs={'placeholder': 'rack price', 'class': 'form-control form-control-alternative'}),
            'no_of_rooms': forms.TextInput(
                attrs={'placeholder': 'Number of rooms', 'class': 'form-control form-control-alternative'}),

        }


class DateInput(forms.DateInput):
    input_type = 'date'


class RoomRate(forms.ModelForm):
    class Meta:
        model = room_rp

        fields = ['hotel_name', 'room_cat_name', 'rate_type', 'rate', 'valid_from', 'valid_to', 'display_name',
                  'extra_adult_price', 'extra_child_price']
        widgets = {
            'hotel_name': forms.Select(attrs={'placeholder': 'Select Hotel Name',
                                              'class': 'category form-control form-control-alternative'}),
            'room_cat_name': forms.Select(
                attrs={'placeholder': 'Room Category', 'class': 'form-control form-control-alternative'}),
            'rate_type': forms.Select(attrs={'placeholder': 'Select Rate Type',
                                             'class': 'category form-control form-control-alternative'}),
            'rate': forms.TextInput(
                attrs={'placeholder': 'rate', 'class': 'form-control form-control-alternative'}),
            'valid_from': DateInput(
                attrs={'placeholder': 'Valid from', 'class': 'form-control form-control-alternative'}),
            'valid_to': DateInput(attrs={'placeholder': 'Valid To',
                                         'class': 'form-control form-control-alternative'}),
            'display_name': forms.TextInput(
                attrs={'placeholder': 'Display Name', 'class': 'form-control form-control-alternative'}),
            'extra_adult_price': forms.TextInput(
                attrs={'placeholder': 'Extra Adult Price', 'class': 'form-control form-control-alternative',
                       'type': 'number'}),
            'extra_child_price': forms.TextInput(
                attrs={'placeholder': 'Extra Child Price', 'class': 'form-control form-control-alternative'}),
        }


class Room_Master(forms.ModelForm):
    class Meta:
        model = room_ms

        fields = ['hotel_name', 'room_cat_name', 'room_no', 'room_status', 'floor', 'capacity', 'add_bed']
        widgets = {
            'hotel_name': forms.Select(attrs={'placeholder': 'Select Hotel Name',
                                              'class': 'category form-control form-control-alternative'}),
            'room_cat_name': forms.Select(
                attrs={'placeholder': 'Room Category', 'class': 'form-control form-control-alternative'}),
            'room_no': forms.TextInput(
                attrs={'placeholder': 'Room Number', 'class': 'form-control form-control-alternative'}),
            'room_status': forms.Select(attrs={'placeholder': 'Select Room Status',
                                               'class': 'category form-control form-control-alternative'}),
            'floor': forms.TextInput(
                attrs={'placeholder': 'Floor', 'class': 'form-control form-control-alternative'}),
            'capacity': forms.TextInput(
                attrs={'placeholder': 'Capacity', 'class': 'form-control form-control-alternative'}),
            'add_bed': forms.TextInput(
                attrs={'placeholder': 'Add Bed', 'class': 'form-control form-control-alternative'}),
        }
